package omega.overmind;

public enum OvermindState{
    scan,
    expand,
    fortify,
    assault,
    stabilize
}
