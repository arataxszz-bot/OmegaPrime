package omega.overmind;

public class OvermindSnapshot{
    public final OvermindState state;
    public final float confidence;
    public final float commandIntensity;
    public final float mapCoverage;

    public OvermindSnapshot(OvermindState state, float confidence, float commandIntensity, float mapCoverage){
        this.state = state;
        this.confidence = confidence;
        this.commandIntensity = commandIntensity;
        this.mapCoverage = mapCoverage;
    }
}
