package omega.overmind;

import omega.adaptive.AdaptiveCommander;
import omega.adaptive.LearningProfile;
import omega.drones.DroneSnapshot;
import omega.systems.PowerSnapshot;
import omega.overmind.ThreatSnapshot;

public class OvermindCore{

    private final ThreatGrid grid = new ThreatGrid();
    private OvermindState state = OvermindState.scan;
    private float confidence = 0.25f;
    private float commandIntensity = 0.35f;
    private float mapCoverage = 0.10f;

    public void update(AdaptiveCommander commander, ThreatSnapshot threat, PowerSnapshot power, DroneSnapshot drones){
        LearningProfile profile = commander.profile();

        grid.sample((long)(profile.memoryThreat * 1000f + profile.memoryPower * 100f), threat.pressure, drones.readiness);

        state = decideState(profile.mode, threat.pressure, power.stability, drones.readiness);
        confidence = lerp(confidence, 0.40f + threat.pressure * 0.30f + drones.readiness * 0.15f, 0.06f);
        commandIntensity = lerp(commandIntensity, profile.aggression * 0.50f + profile.defense * 0.30f + threat.frontlineHeat * 0.20f, 0.05f);
        mapCoverage = lerp(mapCoverage, 0.20f + grid.aggregate() * 0.40f + power.stability * 0.20f, 0.05f);
    }

    private OvermindState decideState(String mode, float danger, float power, float readiness){
        if("assault".equals(mode) && readiness > 0.55f){
            return OvermindState.assault;
        }
        if(danger > 0.70f || "fortify".equals(mode)){
            return OvermindState.fortify;
        }
        if(power < 0.33f){
            return OvermindState.stabilize;
        }
        if(readiness > 0.45f && danger < 0.45f){
            return OvermindState.expand;
        }
        return OvermindState.scan;
    }

    private float lerp(float from, float to, float alpha){
        return from + (to - from) * alpha;
    }

    public OvermindSnapshot snapshot(){
        return new OvermindSnapshot(state, confidence, commandIntensity, mapCoverage);
    }

    public ThreatGrid grid(){
        return grid;
    }

    public OvermindState state(){
        return state;
    }

    public float confidence(){
        return confidence;
    }

    public float commandIntensity(){
        return commandIntensity;
    }

    public float mapCoverage(){
        return mapCoverage;
    }

    public void loadState(OvermindState state, float confidence, float commandIntensity, float mapCoverage){
        if(state != null) this.state = state;
        this.confidence = confidence;
        this.commandIntensity = commandIntensity;
        this.mapCoverage = mapCoverage;
    }
}
