package omega.overmind;

public class ThreatSnapshot{
    public final float pressure;
    public final float enemyDensity;
    public final float waveRisk;
    public final float frontlineHeat;

    public ThreatSnapshot(float pressure, float enemyDensity, float waveRisk, float frontlineHeat){
        this.pressure = pressure;
        this.enemyDensity = enemyDensity;
        this.waveRisk = waveRisk;
        this.frontlineHeat = frontlineHeat;
    }
}
