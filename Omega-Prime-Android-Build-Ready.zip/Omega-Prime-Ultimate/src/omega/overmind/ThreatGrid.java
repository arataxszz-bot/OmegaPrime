package omega.overmind;

public class ThreatGrid{

    private final int width;
    private final int height;
    private final float[][] cells;

    public ThreatGrid(){
        this(12, 12);
    }

    public ThreatGrid(int width, int height){
        this.width = width;
        this.height = height;
        this.cells = new float[height][width];
    }

    public void clear(){
        for(int y = 0; y < height; y++){
            for(int x = 0; x < width; x++){
                cells[y][x] = 0f;
            }
        }
    }

    public void sample(long frame, float pressure, float readiness){
        int x = (int)(frame % width);
        int y = (int)((frame / width) % height);
        cells[y][x] = clamp((cells[y][x] * 0.80f) + pressure * 0.65f + (1f - readiness) * 0.15f);
    }

    public float aggregate(){
        float sum = 0f;
        for(int y = 0; y < height; y++){
            for(int x = 0; x < width; x++){
                sum += cells[y][x];
            }
        }
        return sum / (width * height);
    }

    public float peak(){
        float peak = 0f;
        for(int y = 0; y < height; y++){
            for(int x = 0; x < width; x++){
                peak = Math.max(peak, cells[y][x]);
            }
        }
        return peak;
    }

    public String renderMiniText(){
        StringBuilder builder = new StringBuilder();
        for(int y = 0; y < height; y++){
            for(int x = 0; x < width; x++){
                float v = cells[y][x];
                builder.append(v < 0.2f ? '·' : v < 0.4f ? '░' : v < 0.7f ? '▒' : '█');
            }
            if(y < height - 1) builder.append('\n');
        }
        return builder.toString();
    }

    private float clamp(float value){
        return Math.max(0f, Math.min(1f, value));
    }
}
