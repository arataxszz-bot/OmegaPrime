package omega;

import arc.Events;
import mindustry.game.EventType;
import mindustry.mod.Mod;
import omega.ui.OmegaUI;

public class OmegaPrimeMod extends Mod{

    public static OmegaCore core;

    @Override
    public void loadContent(){
        core = new OmegaCore();
        core.load();

        Events.run(EventType.Trigger.update, () -> {
            if(core != null){
                core.update();
            }
        });

        Events.on(EventType.ClientLoadEvent.class, e -> OmegaUI.install());
    }
}
