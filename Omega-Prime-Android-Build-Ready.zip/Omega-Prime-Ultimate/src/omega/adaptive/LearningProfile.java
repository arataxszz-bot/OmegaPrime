package omega.adaptive;

public class LearningProfile{

    public float aggression = 0.42f;
    public float defense = 0.58f;
    public float economy = 0.50f;
    public float droneBias = 0.50f;
    public float caution = 0.50f;
    public float expansion = 0.50f;

    public float memoryThreat = 0f;
    public float memoryPower = 0f;
    public float memoryDronePressure = 0f;

    public String mode = "balanced";

    public void clamp(){
        aggression = clamp01(aggression);
        defense = clamp01(defense);
        economy = clamp01(economy);
        droneBias = clamp01(droneBias);
        caution = clamp01(caution);
        expansion = clamp01(expansion);
    }

    private float clamp01(float value){
        return Math.max(0f, Math.min(1f, value));
    }
}
