package omega.adaptive;

import omega.drones.DroneSnapshot;
import omega.overmind.ThreatSnapshot;
import omega.systems.PowerSnapshot;

public class AdaptiveCommander{

    private final LearningProfile profile = new LearningProfile();
    private float adaptationClock;

    public void learn(ThreatSnapshot threat, PowerSnapshot power, DroneSnapshot drones){
        adaptationClock += 1f;

        profile.memoryThreat = lerp(profile.memoryThreat, threat.pressure, 0.05f);
        profile.memoryPower = lerp(profile.memoryPower, power.stability, 0.05f);
        profile.memoryDronePressure = lerp(profile.memoryDronePressure, drones.readiness, 0.05f);

        float danger = threat.pressure;
        float energy = power.stability;
        float readiness = drones.readiness;

        profile.caution = lerp(profile.caution, danger * 0.85f + (1f - energy) * 0.25f, 0.06f);
        profile.aggression = lerp(profile.aggression, 0.20f + danger * 0.65f + readiness * 0.15f, 0.05f);
        profile.defense = lerp(profile.defense, 0.35f + danger * 0.50f + (1f - readiness) * 0.15f, 0.05f);
        profile.economy = lerp(profile.economy, 1f - danger * 0.45f, 0.04f);
        profile.droneBias = lerp(profile.droneBias, 0.30f + readiness * 0.55f + danger * 0.15f, 0.05f);
        profile.expansion = lerp(profile.expansion, 0.20f + energy * 0.45f + (1f - danger) * 0.35f, 0.05f);

        profile.mode = chooseMode(danger, energy, readiness);
        profile.clamp();
    }

    private String chooseMode(float danger, float energy, float readiness){
        if(danger > 0.72f){
            return energy > 0.45f ? "fortify" : "contain";
        }
        if(readiness > 0.65f && energy > 0.55f){
            return danger > 0.42f ? "assault" : "expand";
        }
        if(energy < 0.35f){
            return "stabilize";
        }
        return "balanced";
    }

    private float lerp(float from, float to, float alpha){
        return from + (to - from) * alpha;
    }

    public LearningProfile profile(){
        return profile;
    }
}
