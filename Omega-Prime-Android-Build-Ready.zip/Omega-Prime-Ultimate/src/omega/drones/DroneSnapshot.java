package omega.drones;

public class DroneSnapshot{
    public final int total;
    public final int assigned;
    public final float readiness;
    public final String formation;

    public DroneSnapshot(int total, int assigned, float readiness, String formation){
        this.total = total;
        this.assigned = assigned;
        this.readiness = readiness;
        this.formation = formation;
    }
}
