package omega.drones;

import omega.adaptive.AdaptiveCommander;
import omega.adaptive.LearningProfile;
import omega.overmind.OvermindSnapshot;
import omega.overmind.ThreatSnapshot;
import omega.systems.PowerSnapshot;
import omega.systems.ResearchSystem;

public class DroneSwarmSystem{

    private int totalDrones = 24;
    private int assignedDrones = 0;
    private float readiness = 0.55f;
    private float supply = 0.62f;
    private float maintenance = 0.48f;
    private String activeFormation = "mobile";

    private DroneFormation formation = DroneFormation.mobile();

    public void update(AdaptiveCommander commander, OvermindSnapshot overmind, ThreatSnapshot threat, PowerSnapshot power, ResearchSystem research){
        LearningProfile profile = commander.profile();

        formation = chooseFormation(profile.mode, threat.pressure, power.stability, research.researchProgress());
        activeFormation = formation.name;

        float targetReadiness = 0.25f + profile.droneBias * 0.55f + overmind.commandIntensity * 0.20f;
        float targetSupply = 0.30f + power.stability * 0.50f + research.researchProgress() * 0.20f;
        float targetMaintenance = 0.20f + profile.defense * 0.45f + threat.pressure * 0.15f;

        readiness = lerp(readiness, targetReadiness, 0.05f);
        supply = lerp(supply, targetSupply, 0.05f);
        maintenance = lerp(maintenance, targetMaintenance, 0.05f);

        int desired = Math.round(12f + profile.droneBias * 18f + overmind.commandIntensity * 10f);
        desired += research.isUnlocked("adaptive-drone-hubs") ? 8 : 0;
        desired += research.isUnlocked("command-frames") ? 4 : 0;

        assignedDrones = Math.max(0, Math.min(totalDrones, desired));
    }

    private DroneFormation chooseFormation(String mode, float danger, float power, float research){
        if("assault".equals(mode)){
            return DroneFormation.assault();
        }
        if("fortify".equals(mode) || danger > 0.7f){
            return DroneFormation.siege();
        }
        if(power < 0.35f || research < 0.2f){
            return DroneFormation.recovery();
        }
        return DroneFormation.mobile();
    }

    private float lerp(float from, float to, float alpha){
        return from + (to - from) * alpha;
    }

    public DroneSnapshot snapshot(){
        return new DroneSnapshot(totalDrones, assignedDrones, readiness, activeFormation);
    }

    public int totalDrones(){
        return totalDrones;
    }

    public int assignedDrones(){
        return assignedDrones;
    }

    public float readiness(){
        return readiness;
    }

    public float supply(){
        return supply;
    }

    public float maintenance(){
        return maintenance;
    }

    public String activeFormation(){
        return activeFormation;
    }

    public DroneFormation formation(){
        return formation;
    }

    public void loadState(int total, int assigned, float readiness, float supply, float maintenance, String formationName){
        this.totalDrones = Math.max(0, total);
        this.assignedDrones = Math.max(0, assigned);
        this.readiness = readiness;
        this.supply = supply;
        this.maintenance = maintenance;
        this.activeFormation = formationName == null ? "mobile" : formationName;
    }
}
