package omega.drones;

public class DroneFormation{

    public String name;
    public int scouts;
    public int builders;
    public int interceptors;
    public int guards;
    public float spread;
    public float anchor;

    public DroneFormation(String name, int scouts, int builders, int interceptors, int guards, float spread, float anchor){
        this.name = name;
        this.scouts = scouts;
        this.builders = builders;
        this.interceptors = interceptors;
        this.guards = guards;
        this.spread = spread;
        this.anchor = anchor;
    }

    public static DroneFormation mobile(){
        return new DroneFormation("mobile", 4, 3, 6, 2, 0.35f, 0.20f);
    }

    public static DroneFormation siege(){
        return new DroneFormation("siege", 2, 6, 4, 4, 0.22f, 0.55f);
    }

    public static DroneFormation assault(){
        return new DroneFormation("assault", 2, 1, 10, 3, 0.42f, 0.75f);
    }

    public static DroneFormation recovery(){
        return new DroneFormation("recovery", 5, 4, 2, 2, 0.18f, 0.10f);
    }
}
