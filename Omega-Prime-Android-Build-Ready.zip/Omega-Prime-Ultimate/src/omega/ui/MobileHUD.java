package omega.ui;

import arc.scene.event.Touchable;
import arc.scene.ui.layout.Table;
import mindustry.Vars;

public class MobileHUD{

    private static boolean installed;

    public static void install(){
        if(installed) return;
        installed = true;

        Table root = new Table();
        root.top().right();
        root.setFillParent(true);
        root.margin(12f);
        root.touchable = Touchable.enabled;

        root.button("Ω Menu", OmegaMenu::show).size(180f, 64f).pad(4f).row();
        root.button("Overmind", OvermindPanel::show).size(180f, 64f).pad(4f).row();
        root.button("Squads", SquadPanel::show).size(180f, 64f).pad(4f).row();
        root.button("Research", ResearchPanel::show).size(180f, 64f).pad(4f).row();
        root.button("Settings", SettingsPanel::show).size(180f, 64f).pad(4f);

        root.update(() -> root.visible = Vars.state.isPlaying());

        Vars.ui.hudGroup.addChild(root);
    }
}
