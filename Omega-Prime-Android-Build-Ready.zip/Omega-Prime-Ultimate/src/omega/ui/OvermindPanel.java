package omega.ui;

import mindustry.ui.dialogs.BaseDialog;
import omega.OmegaPrimeMod;

public class OvermindPanel extends BaseDialog{

    private static OvermindPanel instance;

    public OvermindPanel(){
        super("Overmind");
        rebuild();
    }

    public static void show(){
        if(instance == null) instance = new OvermindPanel();
        instance.rebuild();
        instance.show();
    }

    private void rebuild(){
        cont.clear();
        buttons.clear();

        cont.pane(t -> {
            t.defaults().pad(5f).growX();
            if(OmegaPrimeMod.core == null){
                t.add("Core not initialized.").row();
                return;
            }

            var overmind = OmegaPrimeMod.core.overmind();
            t.add("[accent]Overmind state:[white] " + overmind.state().name()).row();
            t.add("[accent]Confidence:[white] " + (int)(overmind.confidence() * 100f) + "%").row();
            t.add("[accent]Command intensity:[white] " + (int)(overmind.commandIntensity() * 100f) + "%").row();
            t.add("[accent]Coverage:[white] " + (int)(overmind.mapCoverage() * 100f) + "%").row();
            t.add("").row();
            t.add("[lightgray]Threat grid[]").row();
            t.add(OmegaPrimeMod.core.overmind().grid().renderMiniText()).fontScale(0.85f).row();
        }).grow();

        buttons.button("Close", this::hide).size(180f, 56f);
    }
}
