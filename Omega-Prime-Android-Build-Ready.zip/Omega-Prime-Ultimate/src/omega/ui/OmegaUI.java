package omega.ui;

import arc.Core;
import mindustry.Vars;

public class OmegaUI{

    private static boolean installed;

    public static void install(){
        if(installed) return;
        installed = true;

        Vars.ui.menufrag.addButton("Omega Prime", OmegaMenu::show);
        MobileHUD.install();
    }

    public static boolean isCompact(){
        return Core.graphics.getWidth() < Core.graphics.getHeight();
    }
}
