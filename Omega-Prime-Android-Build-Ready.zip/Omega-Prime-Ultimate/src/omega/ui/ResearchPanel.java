package omega.ui;

import mindustry.ui.dialogs.BaseDialog;
import omega.OmegaPrimeMod;

public class ResearchPanel extends BaseDialog{

    private static ResearchPanel instance;

    public ResearchPanel(){
        super("Research Tree");
        rebuild();
    }

    public static void show(){
        if(instance == null) instance = new ResearchPanel();
        instance.rebuild();
        instance.show();
    }

    private void rebuild(){
        cont.clear();
        buttons.clear();

        cont.pane(t -> {
            t.defaults().pad(5f).growX();
            if(OmegaPrimeMod.core == null){
                t.add("Core not initialized.").row();
                return;
            }

            var research = OmegaPrimeMod.core.researchSystem();
            t.add("[accent]Progress:[white] " + (int)(research.researchProgress() * 100f) + "%").row();
            t.add("[lightgray]Unlocks[]").row();
            research.unlocks().forEach((key, unlocked) -> {
                t.add((unlocked ? "[green]✓ " : "[gray]• ") + key).row();
            });
            t.add("").row();
            t.add("[lightgray]This panel is a source-level progression scaffold. Hook your actual tech nodes here later.[]").wrap().row();
        }).grow();

        buttons.button("Close", this::hide).size(180f, 56f);
    }
}
