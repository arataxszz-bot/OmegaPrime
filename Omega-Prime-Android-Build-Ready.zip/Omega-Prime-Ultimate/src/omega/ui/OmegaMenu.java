package omega.ui;

import arc.Core;
import arc.math.Mathf;
import mindustry.Vars;
import mindustry.ui.dialogs.BaseDialog;
import omega.OmegaPrimeMod;
import omega.adaptive.LearningProfile;
import omega.overmind.OvermindSnapshot;
import omega.systems.PowerSnapshot;
import omega.overmind.ThreatSnapshot;
import omega.drones.DroneSnapshot;

public class OmegaMenu extends BaseDialog{

    private static OmegaMenu instance;

    public OmegaMenu(){
        super("Ω OMEGA PRIME");
        rebuild();
    }

    public static void show(){
        if(instance == null){
            instance = new OmegaMenu();
        }
        instance.rebuild();
        instance.show();
    }

    private void rebuild(){
        cont.clear();
        buttons.clear();

        float width = Core.graphics.getWidth();
        boolean compact = width < Core.graphics.getHeight();

        cont.pane(t -> {
            t.defaults().pad(6f).growX();

            t.table(header -> {
                header.left();
                header.add("[accent]OMEGA PRIME[]").growX();
                header.row();
                header.add(compact ? "Mobile command layout" : "Commander control layout");
            }).growX().row();

            t.table(stats -> {
                stats.left();
                stats.defaults().growX().pad(4f);
                stats.add(sectionTitle("Commander")).row();
                stats.add(statLine("Mode", mode()));
                stats.add(statLine("Aggression", pct(profile().aggression)));
                stats.add(statLine("Defense", pct(profile().defense)));
                stats.add(statLine("Economy", pct(profile().economy)));
                stats.add(statLine("Drone bias", pct(profile().droneBias)));
                stats.add(statLine("Caution", pct(profile().caution)));
                stats.add(statLine("Expansion", pct(profile().expansion)));
                stats.row();

                stats.add(sectionTitle("Overmind")).row();
                stats.add(statLine("State", state()));
                stats.add(statLine("Confidence", pct(overmind().confidence)));
                stats.add(statLine("Command intensity", pct(overmind().commandIntensity)));
                stats.add(statLine("Map coverage", pct(overmind().mapCoverage)));

                stats.row();
                stats.add(sectionTitle("Swarm")).row();
                stats.add(statLine("Formation", drones().formation));
                stats.add(statLine("Total drones", String.valueOf(drones().total)));
                stats.add(statLine("Assigned", String.valueOf(drones().assigned)));
                stats.add(statLine("Readiness", pct(drones().readiness)));

                stats.row();
                stats.add(sectionTitle("Threat")).row();
                stats.add(statLine("Pressure", pct(threat().pressure)));
                stats.add(statLine("Density", pct(threat().enemyDensity)));
                stats.add(statLine("Wave risk", pct(threat().waveRisk)));
                stats.add(statLine("Frontline heat", pct(threat().frontlineHeat)));
            }).growX().row();

            t.add("").height(8f).row();

            t.table(actions -> {
                actions.defaults().size(compact ? 220f : 180f, 64f).pad(4f);
                actions.button("Overmind Panel", OvermindPanel::show);
                actions.button("Squad Panel", SquadPanel::show);
                actions.row();
                actions.button("Research Tree", ResearchPanel::show);
                actions.button("Settings", SettingsPanel::show);
                actions.row();
                actions.button("Save Now", this::saveNow);
                actions.button("Close", this::hide);
            }).growX();
        }).grow();

        buttons.button("Close", this::hide).size(180f, 56f);
    }

    private void saveNow(){
        if(OmegaPrimeMod.core != null){
            OmegaPrimeMod.core.saveSystem().save(
                OmegaPrimeMod.core.commander(),
                OmegaPrimeMod.core.researchSystem(),
                OmegaPrimeMod.core.overmind(),
                OmegaPrimeMod.core.droneSwarm(),
                OmegaPrimeMod.core.powerSystem(),
                OmegaPrimeMod.core.threatSystem()
            );
        }
    }

    private LearningProfile profile(){
        return OmegaPrimeMod.core == null ? new LearningProfile() : OmegaPrimeMod.core.commander().profile();
    }

    private OvermindSnapshot overmind(){
        return OmegaPrimeMod.core == null ? new OvermindSnapshot(omega.overmind.OvermindState.scan, 0f, 0f, 0f) : OmegaPrimeMod.core.overmind().snapshot();
    }

    private ThreatSnapshot threat(){
        return OmegaPrimeMod.core == null ? new ThreatSnapshot(0f, 0f, 0f, 0f) : OmegaPrimeMod.core.threatSystem().snapshot();
    }

    private PowerSnapshot power(){
        return OmegaPrimeMod.core == null ? new PowerSnapshot(0f, 0f, 0f) : OmegaPrimeMod.core.powerSystem().snapshot();
    }

    private DroneSnapshot drones(){
        return OmegaPrimeMod.core == null ? new DroneSnapshot(0, 0, 0f, "mobile") : OmegaPrimeMod.core.droneSwarm().snapshot();
    }

    private String mode(){
        return profile().mode;
    }

    private String state(){
        return overmind().state.name();
    }

    private String pct(float value){
        return Mathf.clamp(value) > 1f ? "100%" : (int)(Mathf.clamp(value) * 100f) + "%";
    }

    private String statLine(String label, String value){
        return "[lightgray]" + label + ":[white] " + value;
    }

    private String sectionTitle(String label){
        return "[accent]" + label + "[]";
    }
}
