package omega.ui;

import mindustry.ui.dialogs.BaseDialog;
import omega.OmegaPrimeMod;

public class SettingsPanel extends BaseDialog{

    private static SettingsPanel instance;

    public SettingsPanel(){
        super("Omega Settings");
        rebuild();
    }

    public static void show(){
        if(instance == null) instance = new SettingsPanel();
        instance.rebuild();
        instance.show();
    }

    private void rebuild(){
        cont.clear();
        buttons.clear();

        cont.pane(t -> {
            t.defaults().pad(5f).growX();
            t.add("[accent]Omega Prime Settings[]").row();
            t.add("[lightgray]Save system:[white] enabled").row();
            t.add("[lightgray]Main menu button:[white] enabled").row();
            t.add("[lightgray]Mobile HUD launcher:[white] enabled").row();
            t.add("").row();
            t.add("[lightgray]Use the Save Now button in the main menu to persist commander state.[]").wrap().row();
        }).grow();

        buttons.button("Close", this::hide).size(180f, 56f);
    }
}
