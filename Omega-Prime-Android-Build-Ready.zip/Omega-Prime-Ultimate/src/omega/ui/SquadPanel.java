package omega.ui;

import mindustry.ui.dialogs.BaseDialog;
import omega.OmegaPrimeMod;

public class SquadPanel extends BaseDialog{

    private static SquadPanel instance;

    public SquadPanel(){
        super("Squad Manager");
        rebuild();
    }

    public static void show(){
        if(instance == null) instance = new SquadPanel();
        instance.rebuild();
        instance.show();
    }

    private void rebuild(){
        cont.clear();
        buttons.clear();

        cont.pane(t -> {
            t.defaults().pad(5f).growX();
            if(OmegaPrimeMod.core == null){
                t.add("Core not initialized.").row();
                return;
            }

            var drones = OmegaPrimeMod.core.droneSwarm();
            t.add("[accent]Formation:[white] " + drones.activeFormation()).row();
            t.add("[accent]Total drones:[white] " + drones.totalDrones()).row();
            t.add("[accent]Assigned:[white] " + drones.assignedDrones()).row();
            t.add("[accent]Readiness:[white] " + (int)(drones.readiness() * 100f) + "%").row();
            t.add("[accent]Supply:[white] " + (int)(drones.supply() * 100f) + "%").row();
            t.add("[accent]Maintenance:[white] " + (int)(drones.maintenance() * 100f) + "%").row();
            t.add("").row();
            t.add("[lightgray]Mobile UI favors a single-column layout for thumbs, because apparently fingers are the enemy of clarity.[]").wrap().row();
        }).grow();

        buttons.button("Close", this::hide).size(180f, 56f);
    }
}
