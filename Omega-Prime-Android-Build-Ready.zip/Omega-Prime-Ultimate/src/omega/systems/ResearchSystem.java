package omega.systems;

import java.util.LinkedHashMap;
import java.util.Map;

public class ResearchSystem{

    private final Map<String, Boolean> unlocks = new LinkedHashMap<>();
    private float researchProgress = 0.18f;

    public ResearchSystem(){
        unlocks.put("adaptive-drone-hubs", Boolean.FALSE);
        unlocks.put("command-frames", Boolean.FALSE);
        unlocks.put("overmind-minimap", Boolean.FALSE);
        unlocks.put("rapid-repair", Boolean.FALSE);
        unlocks.put("tactical-ping", Boolean.FALSE);
    }

    public void tick(float power, float threat, float commanderAggression){
        researchProgress = clamp01(researchProgress + power * 0.004f + (1f - threat) * 0.002f + commanderAggression * 0.001f);

        if(researchProgress > 0.20f) unlock("tactical-ping");
        if(researchProgress > 0.38f) unlock("rapid-repair");
        if(researchProgress > 0.55f) unlock("command-frames");
        if(researchProgress > 0.70f) unlock("adaptive-drone-hubs");
        if(researchProgress > 0.85f) unlock("overmind-minimap");
    }

    public boolean isUnlocked(String key){
        Boolean value = unlocks.get(key);
        return value != null && value.booleanValue();
    }

    public void unlock(String key){
        unlocks.put(key, Boolean.TRUE);
    }

    public float researchProgress(){
        return researchProgress;
    }

    public Map<String, Boolean> unlocks(){
        return unlocks;
    }

    public void loadState(float researchProgress, String rawUnlocks){
        this.researchProgress = researchProgress;
        if(rawUnlocks == null || rawUnlocks.isBlank()) return;
        for(String token : rawUnlocks.split(",")){
            String key = token.trim();
            if(!key.isEmpty()) unlocks.put(key, Boolean.TRUE);
        }
    }

    public String saveUnlocks(){
        StringBuilder builder = new StringBuilder();
        boolean first = true;
        for(Map.Entry<String, Boolean> entry : unlocks.entrySet()){
            if(Boolean.TRUE.equals(entry.getValue())){
                if(!first) builder.append(',');
                builder.append(entry.getKey());
                first = false;
            }
        }
        return builder.toString();
    }

    private float clamp01(float value){
        return Math.max(0f, Math.min(1f, value));
    }
}
