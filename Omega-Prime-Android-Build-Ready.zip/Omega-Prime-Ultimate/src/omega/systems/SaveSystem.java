package omega.systems;

import arc.Core;
import omega.adaptive.AdaptiveCommander;
import omega.adaptive.LearningProfile;
import omega.drones.DroneSwarmSystem;
import omega.overmind.OvermindCore;
import omega.overmind.OvermindState;

public class SaveSystem{

    private static final String PREFIX = "omega-prime-";

    public void load(AdaptiveCommander commander, ResearchSystem research, OvermindCore overmind, DroneSwarmSystem drones){
        LearningProfile profile = commander.profile();

        profile.aggression = Core.settings.getFloat(PREFIX + "aggression", profile.aggression);
        profile.defense = Core.settings.getFloat(PREFIX + "defense", profile.defense);
        profile.economy = Core.settings.getFloat(PREFIX + "economy", profile.economy);
        profile.droneBias = Core.settings.getFloat(PREFIX + "drone-bias", profile.droneBias);
        profile.caution = Core.settings.getFloat(PREFIX + "caution", profile.caution);
        profile.expansion = Core.settings.getFloat(PREFIX + "expansion", profile.expansion);
        profile.mode = Core.settings.getString(PREFIX + "mode", profile.mode);

        research.loadState(
            Core.settings.getFloat(PREFIX + "research-progress", research.researchProgress()),
            Core.settings.getString(PREFIX + "research-unlocks", research.saveUnlocks())
        );

        overmind.loadState(
            parseState(Core.settings.getString(PREFIX + "overmind-state", OvermindState.scan.name())),
            Core.settings.getFloat(PREFIX + "overmind-confidence", 0.25f),
            Core.settings.getFloat(PREFIX + "overmind-intensity", 0.35f),
            Core.settings.getFloat(PREFIX + "overmind-coverage", 0.10f)
        );

        drones.loadState(
            Core.settings.getInt(PREFIX + "drone-total", drones.totalDrones()),
            Core.settings.getInt(PREFIX + "drone-assigned", drones.assignedDrones()),
            Core.settings.getFloat(PREFIX + "drone-readiness", drones.readiness()),
            Core.settings.getFloat(PREFIX + "drone-supply", drones.supply()),
            Core.settings.getFloat(PREFIX + "drone-maintenance", drones.maintenance()),
            Core.settings.getString(PREFIX + "drone-formation", drones.activeFormation())
        );
    }

    public void save(AdaptiveCommander commander, ResearchSystem research, OvermindCore overmind, DroneSwarmSystem drones, PowerSystem power, ThreatSystem threat){
        LearningProfile profile = commander.profile();

        Core.settings.put(PREFIX + "aggression", profile.aggression);
        Core.settings.put(PREFIX + "defense", profile.defense);
        Core.settings.put(PREFIX + "economy", profile.economy);
        Core.settings.put(PREFIX + "drone-bias", profile.droneBias);
        Core.settings.put(PREFIX + "caution", profile.caution);
        Core.settings.put(PREFIX + "expansion", profile.expansion);
        Core.settings.put(PREFIX + "mode", profile.mode);

        Core.settings.put(PREFIX + "research-progress", research.researchProgress());
        Core.settings.put(PREFIX + "research-unlocks", research.saveUnlocks());

        Core.settings.put(PREFIX + "overmind-state", overmind.state().name());
        Core.settings.put(PREFIX + "overmind-confidence", overmind.confidence());
        Core.settings.put(PREFIX + "overmind-intensity", overmind.commandIntensity());
        Core.settings.put(PREFIX + "overmind-coverage", overmind.mapCoverage());

        Core.settings.put(PREFIX + "drone-total", drones.totalDrones());
        Core.settings.put(PREFIX + "drone-assigned", drones.assignedDrones());
        Core.settings.put(PREFIX + "drone-readiness", drones.readiness());
        Core.settings.put(PREFIX + "drone-supply", drones.supply());
        Core.settings.put(PREFIX + "drone-maintenance", drones.maintenance());
        Core.settings.put(PREFIX + "drone-formation", drones.activeFormation());

        Core.settings.put(PREFIX + "power-stability", power.stability());
        Core.settings.put(PREFIX + "power-pressure", power.pressure());
        Core.settings.put(PREFIX + "power-reserve", power.reserve());

        Core.settings.put(PREFIX + "threat-pressure", threat.pressure());
        Core.settings.put(PREFIX + "threat-density", threat.enemyDensity());
        Core.settings.put(PREFIX + "threat-risk", threat.waveRisk());
        Core.settings.put(PREFIX + "threat-heat", threat.frontlineHeat());

        Core.settings.save();
    }

    private OvermindState parseState(String raw){
        try{
            return OvermindState.valueOf(raw);
        }catch(Throwable ignored){
            return OvermindState.scan;
        }
    }
}
