package omega.systems;

import omega.adaptive.AdaptiveCommander;
import omega.drones.DroneSnapshot;
import omega.overmind.ThreatSnapshot;

public class ThreatSystem{

    private float pressure = 0.28f;
    private float enemyDensity = 0.25f;
    private float waveRisk = 0.20f;
    private float frontlineHeat = 0.16f;

    public void sample(long frame, AdaptiveCommander commander, DroneSnapshot drones, PowerSystem power){
        float learning = commander.profile().caution;
        float readiness = drones.readiness;

        pressure = lerp(pressure, 0.15f + learning * 0.40f + (1f - power.stability()) * 0.30f, 0.05f);
        enemyDensity = lerp(enemyDensity, 0.10f + readiness * 0.25f + (frame % 8) * 0.02f, 0.04f);
        waveRisk = lerp(waveRisk, 0.20f + pressure * 0.50f + (1f - power.reserve()) * 0.20f, 0.04f);
        frontlineHeat = lerp(frontlineHeat, 0.20f + pressure * 0.45f + (1f - readiness) * 0.20f, 0.05f);
    }

    private float lerp(float from, float to, float alpha){
        return from + (to - from) * alpha;
    }

    public ThreatSnapshot snapshot(){
        return new ThreatSnapshot(clamp01(pressure), clamp01(enemyDensity), clamp01(waveRisk), clamp01(frontlineHeat));
    }

    public float pressure(){
        return pressure;
    }

    public float enemyDensity(){
        return enemyDensity;
    }

    public float waveRisk(){
        return waveRisk;
    }

    public float frontlineHeat(){
        return frontlineHeat;
    }

    public void loadState(float pressure, float enemyDensity, float waveRisk, float frontlineHeat){
        this.pressure = pressure;
        this.enemyDensity = enemyDensity;
        this.waveRisk = waveRisk;
        this.frontlineHeat = frontlineHeat;
    }

    private float clamp01(float value){
        return Math.max(0f, Math.min(1f, value));
    }
}
