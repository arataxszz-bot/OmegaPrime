package omega.systems;

public class PowerSnapshot{
    public final float stability;
    public final float pressure;
    public final float reserve;

    public PowerSnapshot(float stability, float pressure, float reserve){
        this.stability = stability;
        this.pressure = pressure;
        this.reserve = reserve;
    }
}
