package omega.systems;

public class PowerSystem{

    private float stability = 0.58f;
    private float pressure = 0.22f;
    private float reserve = 0.65f;

    public void update(float danger, float drones, float research){
        float targetStability = 0.32f + reserve * 0.35f + drones * 0.12f - danger * 0.20f;
        float targetPressure = danger * 0.60f + (1f - reserve) * 0.20f;
        float targetReserve = 0.40f + research * 0.35f + drones * 0.10f - danger * 0.10f;

        stability = lerp(stability, clamp01(targetStability), 0.06f);
        pressure = lerp(pressure, clamp01(targetPressure), 0.06f);
        reserve = lerp(reserve, clamp01(targetReserve), 0.05f);
    }

    private float lerp(float from, float to, float alpha){
        return from + (to - from) * alpha;
    }

    private float clamp01(float value){
        return Math.max(0f, Math.min(1f, value));
    }

    public PowerSnapshot snapshot(){
        return new PowerSnapshot(stability, pressure, reserve);
    }

    public float stability(){
        return stability;
    }

    public float pressure(){
        return pressure;
    }

    public float reserve(){
        return reserve;
    }

    public void loadState(float stability, float pressure, float reserve){
        this.stability = stability;
        this.pressure = pressure;
        this.reserve = reserve;
    }
}
