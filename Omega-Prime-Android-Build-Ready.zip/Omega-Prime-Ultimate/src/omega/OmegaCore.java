package omega;

import omega.adaptive.AdaptiveCommander;
import omega.drones.DroneSwarmSystem;
import omega.overmind.OvermindCore;
import omega.systems.PowerSystem;
import omega.systems.ResearchSystem;
import omega.systems.SaveSystem;
import omega.systems.ThreatSystem;

public class OmegaCore{

    private final ThreatSystem threatSystem = new ThreatSystem();
    private final PowerSystem powerSystem = new PowerSystem();
    private final ResearchSystem researchSystem = new ResearchSystem();
    private final SaveSystem saveSystem = new SaveSystem();
    private final DroneSwarmSystem droneSwarm = new DroneSwarmSystem();
    private final AdaptiveCommander commander = new AdaptiveCommander();
    private final OvermindCore overmind = new OvermindCore();

    private long frames;
    private float accumulator;
    private float autosaveClock;

    public void load(){
        saveSystem.load(commander, researchSystem, overmind, droneSwarm);
    }

    public void update(){
        frames++;
        accumulator += 1f;

        if(accumulator >= 1f){
            accumulator = 0f;

            threatSystem.sample(frames, commander, droneSwarm.snapshot(), powerSystem);
            powerSystem.update(threatSystem.pressure(), droneSwarm.readiness(), researchSystem.researchProgress());
            researchSystem.tick(powerSystem.stability(), threatSystem.pressure(), commander.profile().aggression);

            commander.learn(threatSystem.snapshot(), powerSystem.snapshot(), droneSwarm.snapshot());
            overmind.update(commander, threatSystem.snapshot(), powerSystem.snapshot(), droneSwarm.snapshot());
            droneSwarm.update(commander, overmind.snapshot(), threatSystem.snapshot(), powerSystem.snapshot(), researchSystem);
        }

        autosaveClock += 1f;
        if(autosaveClock >= 300f){
            autosaveClock = 0f;
            saveSystem.save(commander, researchSystem, overmind, droneSwarm, powerSystem, threatSystem);
        }
    }

    public ThreatSystem threatSystem(){
        return threatSystem;
    }

    public PowerSystem powerSystem(){
        return powerSystem;
    }

    public ResearchSystem researchSystem(){
        return researchSystem;
    }

    public SaveSystem saveSystem(){
        return saveSystem;
    }

    public DroneSwarmSystem droneSwarm(){
        return droneSwarm;
    }

    public AdaptiveCommander commander(){
        return commander;
    }

    public OvermindCore overmind(){
        return overmind;
    }
}
